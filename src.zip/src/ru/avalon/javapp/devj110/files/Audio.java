package ru.avalon.javapp.devj110.files;

public class Audio extends MultimediaFile {

    public Audio(String name, long size, String format, String descr, Duration duration) {
        super(name, size, format, descr, duration);
    }

    @Override
    String getDetails() {
        return getFormat() + ", " + getDescr() + ", " + getDuration().durationString();
    }
}
